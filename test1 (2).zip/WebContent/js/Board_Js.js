	function null_check() {
		
	}
