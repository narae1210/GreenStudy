package Bean;

public class Board_Dto {

	int postid;
	String posttitle;
	String postcategory;
	String postcontents;
	String name;
	String date;
	String answer;

	public int getPostid() {
		return postid;
	}
	public void setPostid(int postid) {
		this.postid = postid;
	}
	public String getPosttitle() {
		return posttitle;
	}
	public void setPosttitle(String posttitle) {
		this.posttitle = posttitle;
	}
	public String getPostcategory() {
		return postcategory;
	}
	public void setPostcategory(String postcategory) {
		this.postcategory = postcategory;
	}
	public String getPostcontents() {
		return postcontents;
	}
	public void setPostcontents(String postcontents) {
		this.postcontents = postcontents;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
}
