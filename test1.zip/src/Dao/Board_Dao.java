package Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import Bean.Board_Dto;

public class Board_Dao {

	private final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	private final String DB_URl = "jdbc:mysql://localhost/myweb?useSSL=false&useUnicode=true&characterEncoding=utf8"; 
	private final String USER_NAME = "root";
	private final String PASSWORD = "1005";

	Connection conn = null;
	Statement state = null;
	
	public void Db_Dao() { 
		try {
			Class.forName(JDBC_DRIVER); 
			} catch (Exception e) {
		}
	}

	public void DbConnect() { 
		try {
			System.out.println("dbĿ��Ʈ�޼ҵ����");
			conn = DriverManager.getConnection(DB_URl, USER_NAME, PASSWORD);
		} catch (Exception e) {
		}
	}

	public void Close() { 
		if (state != null) {
			try {
				state.close();
			} catch (Exception e) {
			}

			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {

				}
		}
	}
	
	/* ����Ʈ �޼��带 ��� �����ϱ� �ٶ� */
	public ArrayList<Board_Dto> Select()
	{
		ArrayList<Board_Dto> bdt = new ArrayList<Board_Dto>(); 
			try {
				Db_Dao();
				DbConnect();
				System.out.println("Select �޼ҵ����");
				state = conn.createStatement();
				String s = String.format("select * from qnaboard;"); 
				ResultSet aa = state.executeQuery(s);
				
				while (aa.next()) {
					Board_Dto post = new Board_Dto();
					post.setPosttitle(aa.getString("posttitle"));
					post.setPostcontents(aa.getString("postcontents"));
					post.setName(aa.getString("name"));
					post.setDate(aa.getString("date"));
					post.setPostcategory(aa.getString("postcategory"));
					post.setAnswer(aa.getString("answer"));
					bdt.add(post);
					}
			} catch (Exception e) {
				System.out.println(e);
			} finally {
				Close();
			}
			return(bdt);
	}
	
	
	public void Insert(String n1, String n2, String n3, String n4) {
		try {
			System.out.println("Insert�޼ҵ� ����");
			Db_Dao();
			DbConnect();
			state = conn.createStatement();
			System.out.println(n1);
			System.out.println(n2);
			System.out.println(n3);
			System.out.println(n4);
			System.out.println("���̺��Է½õ�");
			String input = String.format("Insert into qnaboard (posttitle, postcategory, postcontents, name, date, answer) values('%s','%s','%s','%s', now(),'�̴亯')", n1,
					n2, n3, n4);
			
			int num = state.executeUpdate(input);
			if( num == 1)
				System.out.println("���̺��Է¿Ϸ�"); 
		} catch (Exception e) {
		} finally {
			Close();
		}
	}
}