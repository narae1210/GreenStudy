package Action;

public class BoardListAction {

}
