package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Db_Dao {

	private final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	private final String DB_URl = "jdbc:mysql://localhost/myweb"; 
	private final String USER_NAME = "root";
	private final String PASSWORD = "1005";

	Connection conn = null;
	Statement state = null;

	public void Db_Dao() { 
		try {
			Class.forName(JDBC_DRIVER); 
			} catch (Exception e) {
		}
	}

	public void DbConnect() { 
		try {
			System.out.println("db커넥트메소드실행");
			conn = DriverManager.getConnection(DB_URl, USER_NAME, PASSWORD);
		} catch (Exception e) {
		}
	}

	public void Close() { 
		if (state != null) {
			try {
				state.close();
			} catch (Exception e) {
			}

			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
			}
		}
	}

	public void Insert(String n1, String n2, String n3, String n4, String n5, String n6, String n7, String n8,
			String n9) {
		try {
			System.out.println("Insert메소드 실행");
			Db_Dao();
			DbConnect();
			state = conn.createStatement();
			System.out.println("테이블입력시도");
			String input = String.format("Insert into Gs_Join values('%s','%s','%s','%s','%s','%s','%s','%s','%s')", n1,
					n2, n3, n4, n5, n6, n7, n8, n9);
			
			int num = state.executeUpdate(input);
			if( num == 1)
				System.out.println("테이블입력완료"); 
		} catch (Exception e) {
		} finally {
			Close();
		}
	}

	public int Jungbok(String s1) {
		int n = 0;
		try {
			Db_Dao();
			DbConnect();
			System.out.println("Jungbok메소드실행");
			state = conn.createStatement();
			String s = String.format("select id from Gs_Join where id = '%s';", s1); 
			System.out.println(s);
			ResultSet aa = state.executeQuery(s);
			if (aa.next()) {
				n = 1;
			} else {
				n = 0;
			}
			aa.close();
		} catch (Exception e) {
		} finally {
			Close();
		}
		return n;
	}

	public String JungbokPw(String s1) {
		String s = null;
		String ss = null;
		try {
			Db_Dao();
			DbConnect();
			state = conn.createStatement(); 
			s = String.format("select pw from Gs_Join where id = '%s';", s1);
			ResultSet aa = state.executeQuery(s);
			if(aa.next()) {
				ss = aa.getString("pw");
			}
		} catch (Exception e) {
		} finally {
			Close();
		}
		return ss;
	}
}