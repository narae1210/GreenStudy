package model;

public class SangpumDto {
int dept_id;
String dname;

public int getDept_id() {
	return dept_id;
}
public void setDept_id(int dept_id) {
	this.dept_id = dept_id;
}
public String getDname() {
	return dname;
}
public void setDname(String dname) {
	this.dname = dname;
}

}
