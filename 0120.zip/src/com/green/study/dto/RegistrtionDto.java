package com.green.study.dto;

public class RegistrtionDto {

	String s_title, s_type, main_language, secound_language, s_summary, s_expect, s_effect, id;
	int people_num, s_firstday, s_lastday, page, num, hit, s_num;
	
	public int getS_num() {
		return s_num;
	}

	public void setS_num(int s_num) {
		this.s_num = s_num;
	}
	
	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getHit() {
		return hit;
	}

	public void setHit(int hit) {
		this.hit = hit;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getS_title() {
		return s_title;
	}

	public void setS_title(String s_title) {
		this.s_title = s_title;
	}

	public String getS_type() {
		return s_type;
	}

	public void setS_type(String s_type) {
		this.s_type = s_type;
	}

	public String getMain_language() {
		return main_language;
	}

	public void setMain_language(String main_language) {
		this.main_language = main_language;
	}

	public String getSecound_language() {
		return secound_language;
	}

	public void setSecound_language(String secound_language) {
		this.secound_language = secound_language;
	}

	public String getS_summary() {
		return s_summary;
	}

	public void setS_summary(String s_summary) {
		this.s_summary = s_summary;
	}

	public String getS_expect() {
		return s_expect;
	}

	public void setS_expect(String s_expect) {
		this.s_expect = s_expect;
	}

	public String getS_effect() {
		return s_effect;
	}

	public void setS_effect(String s_effect) {
		this.s_effect = s_effect;
	}

	public int getPeople_num() {
		return people_num;
	}

	public void setPeople_num(int people_num) {
		this.people_num = people_num;
	}

	public int getS_firstday() {
		return s_firstday;
	}

	public void setS_firstday(int s_firstday) {
		this.s_firstday = s_firstday;
	}

	public int getS_lastday() {
		return s_lastday;
	}

	public void setS_lastday(int s_lastday) {
		this.s_lastday = s_lastday;
	}

}
