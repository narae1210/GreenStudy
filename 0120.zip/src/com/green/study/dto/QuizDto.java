package com.green.study.dto;

public class QuizDto {
	
	int quizid;
	String quiztheme;
	String quiztitle;
	String quiz;
	String quizin;
	String quizout;
	String quizinex;
	String quizoutex;
	String quizlevel;
	int quizanswer;
	
	public int getQuizid() {
		return quizid;
	}
	public void setQuizid(int quizid) {
		this.quizid = quizid;
	}
	public String getQuiztheme() {
		return quiztheme;
	}
	public void setQuiztheme(String quiztheme) {
		this.quiztheme = quiztheme;
	}
	public String getQuiztitle() {
		return quiztitle;
	}
	public void setQuiztitle(String quiztitle) {
		this.quiztitle = quiztitle;
	}
	public String getQuiz() {
		return quiz;
	}
	public void setQuiz(String quiz) {
		this.quiz = quiz;
	}
	public String getQuizin() {
		return quizin;
	}
	public void setQuizin(String quizin) {
		this.quizin = quizin;
	}
	public String getQuizout() {
		return quizout;
	}
	public void setQuizout(String quizout) {
		this.quizout = quizout;
	}
	public String getQuizinex() {
		return quizinex;
	}
	public void setQuizinex(String quizinex) {
		this.quizinex = quizinex;
	}
	public String getQuizoutex() {
		return quizoutex;
	}
	public void setQuizoutex(String quizoutex) {
		this.quizoutex = quizoutex;
	}
	public String getQuizlevel() {
		return quizlevel;
	}
	public void setQuizlevel(String quizlevel) {
		this.quizlevel = quizlevel;
	}
	public int getQuizanswer() {
		return quizanswer;
	}
	public void setQuizanswer(int quizanswer) {
		this.quizanswer = quizanswer;
	}

}
